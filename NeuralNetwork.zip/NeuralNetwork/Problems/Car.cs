﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace NeuralNetwork.Problems
{
    public static class Car
    {
        private static readonly List<string> PossibleResults = new List<string> { "True","False" };

        public static void Run()
        {
            // Settings
            var filePath = @"data.csv";
            var epochs = 500; // Number of training iterations
            var inputNodes = 3;
            var hiddenNodes = 5;
            var outputNodes = 2;
            var learningRate = 0.2;
            Program.RandomSetAsRepeatable(true);

            // Read the data and shuffle it
            var shuffledInputs = GetInputs(filePath);
            var trainDataSetCount = Convert.ToInt32(shuffledInputs.Length * 0.67);

            // Create a network with random weights
            var network = new NeuralNetwork(inputNodes, hiddenNodes, outputNodes, learningRate);

            // Train on a random 100 of the 150 data samples
            var trainDataSet = shuffledInputs.Take(trainDataSetCount).ToArray();

            Console.WriteLine($"Training network with {trainDataSet.Length} samples using {epochs} epochs...");

            for (var epoch = 0; epoch < epochs; epoch++)
            {
                foreach (var input in trainDataSet)
                {
                    // Extract the 4 data points from the sample
                    var inputList = input.Take(inputNodes).Select(double.Parse).ToArray();

                    // Extract the correct answer and synthesize a 3-node output with 0.01 indicating wrong answer and 0.99 indicating right one.
                    var targets = new[] { 0.01, 0.01, 0.01 };
                    targets[PossibleResults.IndexOf(input.Last())] = 0.99;

                    // Convert the data to the range 0 - 1.0 (faster to do this outside the epochs loop) 
                    // and train the network.
                    network.Train(NormaliseData(inputList), targets);
                }
            }

            // Test on the rest of the data samples
            var testDataset = shuffledInputs.Skip(trainDataSetCount).ToArray();

            var scoreCard = new List<bool>();
            foreach (var input in testDataset)
            {
                // The node with the largest value is the answer found
                var result = network.Query(NormaliseData(input.Take(4).Select(double.Parse).ToArray())).ToList();
                var predictedResult = PossibleResults[result.IndexOf(result.Max())];

                // The correct answer is in the final field of the input
                var correctResult = PossibleResults[PossibleResults.IndexOf(input.Last())];

                // Note correctness so we can calculate performance of network
                scoreCard.Add(predictedResult == correctResult);

                var miss = (predictedResult == correctResult) ? "" : "miss";
                Console.WriteLine($"{input[0], 4}, {input[1], 4}, {input[2], 4}, {input[3], 4}, {correctResult, -16}, {predictedResult, -16} {miss}");
            }

            Console.WriteLine(
                $"Performance is {(scoreCard.Count(x => x) / Convert.ToDouble(scoreCard.Count)) * 100} percent.");
        }

        // Returns an array with 150 randomly sorted records, each with 5 strings. The last one is the correct category, e.g.:
        // [0]: "5.6"
        // [1]: "2.5"
        // [2]: "3.9"
        // [3]: "1.1"
        // [4]: "Iris-versicolor"
        private static string[][] GetInputs(string filePath)
        {
            var dataset = File.ReadAllLines(filePath);

            var allInputs = dataset.Select(x => x.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)).ToArray();

            return Program.Shuffle(allInputs);
        }

        private static double[] NormaliseData(double[] input)
        {
            var maxSepalLenth = 7.9;
            var maxSepalWidth = 4.4;
            var maxPetalLenth = 6.9;
            var maxPetalWidth = 2.5;

            var normalised = new[]
            {
                (input[0]/maxSepalLenth),
                (input[1]/maxSepalWidth),
                (input[2]/maxPetalLenth),
                (input[3]/maxPetalWidth)
            };

            return normalised;
        }
    }
}
