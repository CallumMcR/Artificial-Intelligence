﻿using System;

namespace NeuralNetwork.Problems
{
    public static class XOR
    {
        public static void Run()
        {
            var hiddenNodes = 5;
            var epochs = 100; // Range 1 to 100,000
            var learningRate = 0.1; // Range 0.01 to 0.5
            Program.RandomSetAsRepeatable(true);

            Console.WriteLine("Creating neural network...");
            var network = new NeuralNetwork(2, hiddenNodes, 1, learningRate);

            Console.WriteLine($"Training network with {4} samples using {epochs} epochs and learning rate {learningRate} ...");
            for (int epoch = 0; epoch < epochs; epoch++)
            {
                network.Train(new[] { 0.01, 0.01 }, new[] { 0.01 });
                network.Train(new[] { 0.01, 0.99 }, new[] { 0.99 });
                network.Train(new[] { 0.99, 0.01 }, new[] { 0.99 });
                network.Train(new[] { 0.99, 0.99 }, new[] { 0.01 });
            }

            var true_1 = network.Query(new[] { 0.99, 0.01 });
            var true_2 = network.Query(new[] { 0.01, 0.99 });
            var false_1 = network.Query(new[] { 0.01, 0.01 });
            var false_2 = network.Query(new[] { 0.99, 0.99 });

            Console.WriteLine($"Networks answer for true_1: {true_1[0]:F2} which is {(true_1[0] > 0.5)}");
            Console.WriteLine($"Networks answer for true_2: {true_2[0]:F2} which is {(true_2[0] > 0.5)}");
            Console.WriteLine($"Networks answer for false_1: {false_1[0]:F2} which is {(false_1[0] > 0.5)}");
            Console.WriteLine($"Networks answer for false_2: {false_2[0]:F2} which is {(false_2[0] > 0.5)}");
        }
    }
}
