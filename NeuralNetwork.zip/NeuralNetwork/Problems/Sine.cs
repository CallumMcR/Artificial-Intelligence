﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace NeuralNetwork.Problems
{
    public static class Sine
    {
        public static void Run()
        {
            var hiddenNodes = 80;
            var epochs = 1; // Range 1 to 100,000
            var learningRate = 0.01; // Range 0.01 to 0.5
            Program.RandomSetAsRepeatable(true);

            Console.WriteLine($"Creating neural network with {hiddenNodes} hidden nodes ...");
            var network = new NeuralNetwork(1, hiddenNodes, 1, learningRate);

            var shuffledInputs = GenerateShuffledInputs();

            var trainDataSet = shuffledInputs.Take(shuffledInputs.Length / 2).ToArray();
            var testDataSet = shuffledInputs.Skip(shuffledInputs.Length / 2).ToArray();

            Console.WriteLine($"Training network with {trainDataSet.Length} samples using {epochs} epochs and learning rate {learningRate} ...");
            for (var epoch = 0; epoch < epochs; epoch++)
            {
                foreach (var data in trainDataSet)
                {
                    var normalizedInput = data / Math.PI; //normalized [-1, 1]
                    var actual = (Math.Sin(data) + 1) / 2; //normalized between [0, 1]

                    network.Train(new[] { normalizedInput }, new[] { actual });
                }
            }

            foreach (var data in testDataSet.OrderBy(x => x).ToArray())
            {
                var normalizedInput = data / Math.PI;
                var predictedResultArray = network.Query(new[] { data });
                var predictedResult = predictedResultArray[0];
                var correctResult = (Math.Sin(data) + 1) / 2;

                var error = Math.Abs(predictedResult - correctResult);
                var miss = (error < 0.4) ? "" : "miss";
                Console.WriteLine($"degrees = {data*180.0/Math.PI:##0.0}, sin = {Math.Sin(data):0.###}, {correctResult, 5:F3}, {predictedResult, 5:F3} {miss}");
            }
        }

        private static double[] GenerateShuffledInputs()
        {
            var inputs = new List<double>();

            for (var x = -Math.PI; x < Math.PI; x += 0.01)
            {
                    inputs.Add(x);
            }

            return inputs.OrderBy(x => Program.Random.NextDouble()).ToArray();
        }
    }
}
