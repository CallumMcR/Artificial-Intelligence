﻿// Based on code from https://github.com/Hagsten/NeuralNetwork/blob/master/README.md

using System;
using System.Linq;

namespace NeuralNetwork
{
    class Program
    {
        public static Random Random;

        static void Main(string[] args)
        {
            //Problems.XOR.Run();
            //Problems.Sine.Run();
            //Problems.HandwrittenDigits.Run();
            Problems.Car.Run();
            //Problems.ShowApprovals.Run();

            Console.WriteLine("Press a key to end"); Console.ReadLine();
        }

        public static void RandomSetAsRepeatable(bool repeatable)
        {
            if (repeatable)
                Random = new Random(0);
            else
                Random = new Random();
        }

        public static string[][] Shuffle(string[][] allInputs)
        {
            // The following statement is a shortcut to randomise an array and is equivalent to the longer:
            // return
            //   .Select(i => new { i, rand = random.NextDouble() }) // insert a temporary random key
            //   .OrderBy(x => x.rand) // sort on the random key
            //   .Select(x => x.i)     // remove the key
            //   .ToArray();
            return allInputs.OrderBy(x => Program.Random.NextDouble()).ToArray();
        }
        public static double[][] Shuffle(double[][] allInputs)
        {
            // The following statement is a shortcut to randomise an array and is equivalent to the longer:
            // return
            //   .Select(i => new { i, rand = random.NextDouble() }) // insert a temporary random key
            //   .OrderBy(x => x.rand) // sort on the random key
            //   .Select(x => x.i)     // remove the key
            //   .ToArray();
            return allInputs.OrderBy(x => Program.Random.NextDouble()).ToArray();
        }
    }
}
